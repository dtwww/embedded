

void equalize (unsigned char *src, int width, int heigth, int format); 
